/**
 * Copyright 2009 Optaros, Inc.
 */

/*
var connector = remote.connect("alfresco");
var statusList = connector.get("/status/history/global");

statusListObj = eval('(' + statusList + ')');


model.items = statusListObj.items;
*/