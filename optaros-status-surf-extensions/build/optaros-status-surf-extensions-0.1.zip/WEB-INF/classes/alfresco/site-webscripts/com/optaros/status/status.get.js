/**
 * Copyright 2009 Optaros, Inc.
 */

/*
var connector = remote.connect("alfresco");
var statusList = connector.get("/status/global");

statusListObj = eval('(' + statusList + ')');


model.items = statusListObj.items;
*/
